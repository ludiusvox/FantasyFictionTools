<?php
    $servername='db-mysql-nyc3-55942-do-user-8781413-0.b.db.ondigitalocean.com';
    $username='doadmin';
    $password='wynegp8i8ecv5e0t';
    $dbname = "Project";
    $conn=mysqli_connect($servername,$username,$password,"$dbname");
      if(!$conn){
          die('Could not Connect MySql Server:' .mysql_error());
        }
     //   while ($row = mysql_fetch_assoc($last_d)){
     //     $newid1= $row['counts'];
     //     $newid0= $newid1+1;
     //     $query1= mysql_query("UPDATE 'CharacterSketch' . 'counts' SET '$newid1= $newid0'");
     //     echo "Previous records:$last_d <br />
     //     Current count:$newid0"; 
     //  }
?>