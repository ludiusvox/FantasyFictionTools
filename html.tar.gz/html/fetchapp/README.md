# Notes_App-using-Node.js-Express.js-mongoDB
A Simple Notes App which can get a string , put it in mongoDB database and then fetches it to show to a webpage using Node.js and Express.js used for routing. This project is for looking at basic mongoDB connections with our Web Application.
